export interface IMediaResponse {
	url: string
	name: string
	size: string
}
